package mil.army.nlac.commons.jobs.model.op;

import java.io.IOException;
import java.net.URL;
import java.nio.file.Path;
import java.time.ZonedDateTime;
import java.time.temporal.ChronoUnit;
import java.util.Optional;
import java.util.UUID;
import java.util.function.Function;

import javax.naming.Name;
import javax.xml.namespace.QName;

import com.fasterxml.jackson.annotation.JsonIgnore;

import mil.army.nlac.commons.core.data.PRONOMUniqueId;
import mil.army.nlac.commons.core.http.MediaType;
import mil.army.nlac.commons.core.io.CoreFileUtils;
import mil.army.nlac.commons.core.naming.ImmutableCompositeName;
import mil.army.nlac.commons.core.util.EnumStringMapper;
import mil.army.nlac.commons.core.util.TimestampRandomUUID;
import mil.army.nlac.commons.core.util.cli.JobEnv;
// @Table (n3_op.OP_DATASET)
public class DataSetMetaData {
	public enum ProcessStatus { 
		NEW("new"),
		SKIP_EXTRA("skip/extra"),
		SKIP_OLDER("skip/older"),
		SKIP_DUPLICATE("skip/duplicate"),
		LOADED("LOADED");
		private String string;
		private ProcessStatus(final String string) { this.string = string; }
		@Override public String toString() { return string; }
		
		public static ProcessStatus forString(final String string) {
			switch(string.toLowerCase()) {
			case "new"            : return NEW;
			case "skip/duplicate" : return SKIP_DUPLICATE;
			case "skip/extra"     : return SKIP_EXTRA;
			case "skip/older"     : return SKIP_OLDER;
			case "loaded"         : return LOADED;
			default: throw new IllegalArgumentException("No such status: "+string);
			}
		}
		
		public static class ProcessStatusStringMapper implements EnumStringMapper<ProcessStatus> {
			public static final Function<ProcessStatus,String> SERIALIZER = 
				new Function<ProcessStatus,String>() {
					@Override public String apply(ProcessStatus t) { return (t==null) ? null : t.toString(); }
				};
			public static final Function<String,ProcessStatus> DESERIALIZER = 
				new Function<String,ProcessStatus>() {
					@Override public ProcessStatus apply(String t) { return (t==null) ? null : ProcessStatus.forString(t); }
				}; 
			@Override public String        serialize(ProcessStatus value) { return SERIALIZER.apply(value); }
			@Override public ProcessStatus deserialize(String value)      { return DESERIALIZER.apply(value); }
		}
	}
	
	
	private UUID            uuid;
	private QName           qName;
	private String          interfaceId;
	private UUID            parentUUID;
	private DataSetMetaData parent;
	private UUID            archiveUUID;
	private DataSetMetaData archive;

	private String          digestSHA256;
	private ZonedDateTime   asOf;
	private ChronoUnit      asOfPrecision;

	private ZonedDateTime   lastModified;
	private ChronoUnit      lastModifiedPrecision;
	
	private URL             externalURL;
	private URL             internalURL;
		
	private MediaType       mediaType;
	private PRONOMUniqueId  puid;

	private ProcessStatus   processStatus;
	
	private UUID          recvTaskRunUUID;
	private ZonedDateTime recvTS;
	
	private UUID          loadTaskRunUUID;
	private ZonedDateTime loadTS;

	private UUID          purgeTaskRunUUID;
	private ZonedDateTime purgeTS;
	
	private ZonedDateTime rowInsTS;
	private ZonedDateTime rowUpdTS;
	private ZonedDateTime rowArcvTS;

	public DataSetMetaData(final UUID uuid) { 
		setUuid(uuid); 
	}
	
	/**
	 * Create new, setting: UUID, rowInsTS, rowUpdTS set
	 */
	public DataSetMetaData() {
		setUuid(TimestampRandomUUID.newUUID());
		setRowInsTS(JobEnv.getNowZonedDateTime());
		setRowUpdTS(JobEnv.getNowZonedDateTime());
	}
	/**
	 * Sets:
	 * 	uuid (new)
	 *  rowInsTS
	 *  rowUpdTS
	 * 	filename
	 *  fileSHA256
	 *  fileStatus
	 *  mediaTypeCode
	 * @param path
	 */
	public DataSetMetaData(final Path path, final ZonedDateTime asOf, final ProcessStatus processStatus, final MediaType mediaTypeCode) {
		this();
		setDataSetName(path.getFileName().toString());
		setAsOf(asOf);
		setProcessStatus(processStatus);
		setMediaType(mediaTypeCode);
		try {
			setDigestSHA256(CoreFileUtils.digestSHA256AsHex(path));
		} catch (IOException ignoree) {
		}
	}
//@formatter:off	
	public UUID          getUuid()           { return uuid; }
	public QName         getQName()          { return qName; }
	public UUID          getParentUUID()     { return parentUUID; }
	public UUID          getArchiveUUID()    { return archiveUUID; }
	public String        getDigestSHA256()   { return digestSHA256; }
	public ZonedDateTime getAsOf()           { return asOf; }
	public ChronoUnit    getAsOfPrecision()  { return asOfPrecision; }
	public ZonedDateTime getLastModified()           { return lastModified; }
	public ChronoUnit    getLastModifiedPrecision()  { return lastModifiedPrecision; }
	public URL           getExternalURL()    { return externalURL; }
	public URL           getInternalURL()    { return internalURL; }
	
	public PRONOMUniqueId getPuid()          { return puid; }
	
	public MediaType     getMediaType()      { return mediaType; }
	
	public ProcessStatus getProcessStatus()  { return processStatus; }

	public UUID          getRecvTaskRunUUID() { return recvTaskRunUUID; }
	public ZonedDateTime getRecvTS()          { return recvTS; }

	public UUID          getLoadTaskRunUUID() { return loadTaskRunUUID; }
	public ZonedDateTime getLoadTS()          { return loadTS; }

	public UUID          getPurgeTaskRunUUID() { return purgeTaskRunUUID; }
	public ZonedDateTime getPurgeTS()          { return purgeTS; }
	
	public ZonedDateTime getRowInsTS()       { return rowInsTS; }
	public ZonedDateTime getRowUpdTS()       { return rowUpdTS; }
	public ZonedDateTime getRowArcvTS()      { return rowArcvTS; }

	@JsonIgnore public DataSetMetaData getParent() { return parent; }
	@JsonIgnore	public DataSetMetaData getArchive() { return archive; }
	@JsonIgnore public ImmutableCompositeName  getInterfaceId()    { return new ImmutableCompositeName(qName.getNamespaceURI()); }
	@JsonIgnore	public ImmutableCompositeName  getDataSetName()    { return new ImmutableCompositeName(qName.getLocalPart()); }
	
	public void setQName(QName qname)                              { this.qName = qname; }
	public void setInterfaceId(String interfaceId)                 { this.qName = new QName(interfaceId,Optional.ofNullable(qName).map(qn -> qn.getLocalPart()).orElse(null)); }
	public void setDataSetName(String name)                        { this.qName = new QName(Optional.ofNullable(qName).map(qn -> qn.getNamespaceURI()).orElse(null), name); }
	
	public DataSetMetaData withInterfaceId(String interfaceId)     { setInterfaceId(interfaceId); return this; }
	public DataSetMetaData withInterfaceId(Name interfaceId)       { setInterfaceId(Optional.ofNullable(interfaceId).map(n -> n.toString()).orElse(null)); return this; }
	public DataSetMetaData withDataSetName(String fileName)        { setDataSetName(fileName); return this; }
	public DataSetMetaData withDataSetName(Path fileName)          { setDataSetName(Optional.ofNullable(fileName).map(f -> f.toString()).orElse(null)); return this; }
	
	public void setUuid(UUID uuid)                          { this.uuid = uuid; }
	public void setParentUUID(UUID parentUUID)              { this.parentUUID = parentUUID; }
	public void setArchiveUUID(UUID archiveUUID)            { this.archiveUUID = archiveUUID; }

	public void setParent(DataSetMetaData parent)           { this.parent = parent;   setParentUUID(Optional.ofNullable(parent).map(u -> u.getUuid()).orElse(null));}
	public void setArchive(DataSetMetaData archive)         { this.archive = archive; setArchiveUUID(Optional.ofNullable(archive).map(u -> u.getUuid()).orElse(null));  }
	
	public void setExternalURL(URL externalURL)             { this.externalURL = externalURL; }
	public void setInternalURL(URL internalURL)             { this.internalURL = internalURL; }

	public void setAsOf(ZonedDateTime asOf)                 { this.asOf = asOf; }
	public void setAsOfPrecision(ChronoUnit asOfPrecision)  { this.asOfPrecision = asOfPrecision; }
	public void setLastModified(ZonedDateTime lastModified)                 { this.lastModified = lastModified; }
	public void setLastModifiedPrecision(ChronoUnit lastModifiedPrecision)  { this.lastModifiedPrecision = lastModifiedPrecision; }
	public void setDigestSHA256(String fileSHA256)          { this.digestSHA256 = fileSHA256; }
	
	public void setMediaType(MediaType mediaTypeCode)        { this.mediaType = mediaTypeCode; }
	public void setPUID(PRONOMUniqueId puid)                 { this.puid = puid; }

	public void setProcessStatus(ProcessStatus fileStatus)   { this.processStatus = fileStatus; }
	public void setRecvJobRunUUID(UUID recvJobRunUUID)       { this.recvTaskRunUUID = recvJobRunUUID; }
	public void setRecvTS(ZonedDateTime recvTS)              { this.recvTS = recvTS; }
	public void setLoadJobRunUUID(UUID loadJobRunUUID)       { this.loadTaskRunUUID = loadJobRunUUID;  }
	public void setLoadTS(ZonedDateTime loadTS)              { this.loadTS = loadTS; }
	public void setPurgeJobRunUUID(UUID loadJobRunUUID)      { this.purgeTaskRunUUID = loadJobRunUUID;  }
	public void setPurgeTS(ZonedDateTime loadTS)             { this.purgeTS = loadTS; }
	public void setRowInsTS(ZonedDateTime rowInsTS)          { this.rowInsTS = rowInsTS; }
	public void setRowUpdTS(ZonedDateTime rowUpdTS)          { this.rowUpdTS = rowUpdTS; }
	public void setRowArcvTS(ZonedDateTime rowArcvTS)        { this.rowArcvTS = rowArcvTS; }
	

	public DataSetMetaData withUUID(UUID uuid)                  { setUuid(uuid); return this; }
	public DataSetMetaData withQName(QName qname)               { setQName(qname); return this; }
	
	public DataSetMetaData withParentUUID(UUID parentUUID)      { setParentUUID(parentUUID); return this; }
	public DataSetMetaData withArchiveUUID(UUID archiveUUID)    { setArchiveUUID(archiveUUID); return this; }

	public DataSetMetaData withParent(DataSetMetaData parent)   { setParent(parent);   setParentUUID(Optional.ofNullable(parent).map(u -> u.getUuid()).orElse(null)); return this; }
	public DataSetMetaData withArchive(DataSetMetaData archive) { setArchive(archive); setArchiveUUID(Optional.ofNullable(archive).map(u -> u.getUuid()).orElse(null)); return this; }

	public DataSetMetaData withExternalURL(URL externalURL)     { setExternalURL(externalURL); return this; }
	public DataSetMetaData withInternalURL(URL internalURL)     { setInternalURL(internalURL); return this; }
	
	public DataSetMetaData withDigestSHA256(String fileSHA256)          { setDigestSHA256(fileSHA256); return this; }
	public DataSetMetaData withAsOf(ZonedDateTime asOf)                 { setAsOf(asOf); return this;}
	public DataSetMetaData withAsOfPrecision(ChronoUnit asOfPrecision)  { setAsOfPrecision(asOfPrecision); return this;}
	public DataSetMetaData withlastModified(ZonedDateTime lastModified)                 { setLastModified(lastModified); return this;}
	public DataSetMetaData withlastModifiedPrecision(ChronoUnit alastModifiedPrecision)  { setLastModifiedPrecision(alastModifiedPrecision); return this;}
	
	public DataSetMetaData withMediaType(MediaType mediaType)           { setMediaType(mediaType); return this; }
	public DataSetMetaData withPUID(PRONOMUniqueId puid)                { setPUID(puid); return this; }

	public DataSetMetaData withProcessStatus(ProcessStatus fileStatus)  { setProcessStatus(fileStatus); return this; }
	public DataSetMetaData withRecvJobRunUUID(UUID recvJobRunUUID)      { setRecvJobRunUUID(recvJobRunUUID); return this; }
	public DataSetMetaData withRecvTS(ZonedDateTime recvTS)             { setRecvTS(recvTS); return this; }
	public DataSetMetaData withLoadJobRunUUID(UUID loadJobRunUUID)      { setLoadJobRunUUID(loadJobRunUUID); return this;  }
	public DataSetMetaData withLoadTS(ZonedDateTime loadTS)             { setLoadTS(loadTS); return this; }
	public DataSetMetaData withPurgeJobRunUUID(UUID loadJobRunUUID)     { setPurgeJobRunUUID(loadJobRunUUID); return this;  }
	public DataSetMetaData withPurgeTS(ZonedDateTime loadTS)            { setPurgeTS(loadTS); return this; }
	public DataSetMetaData withRowInsTS(ZonedDateTime rowInsTS)         { setRowInsTS(rowInsTS); return this; }
	public DataSetMetaData withRowUpdTS(ZonedDateTime rowUpdTS)         { setRowUpdTS(rowUpdTS); return this; }
	public DataSetMetaData withRowArcvTS(ZonedDateTime rowArcvTS)       { setRowArcvTS(rowArcvTS); return this; }
//@formatter:on	
}
