package mil.army.nlac.commons.jobs.model.op;

import static org.junit.jupiter.api.Assertions.fail;

import java.io.IOException;
import java.net.MalformedURLException;
import java.net.URL;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.sql.SQLException;
import java.time.ZonedDateTime;
import java.time.format.DateTimeFormatter;
import java.time.temporal.ChronoUnit;
import java.util.Collections;
import java.util.Map;
import java.util.UUID;
import java.util.regex.Pattern;

import org.junit.jupiter.api.AfterAll;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import mil.army.nlac.commons.core.data.PRONOMUniqueId;
import mil.army.nlac.commons.core.http.MediaType;
import mil.army.nlac.commons.core.io.CoreFileUtils;
import mil.army.nlac.commons.core.naming.ImmutableCompositeName;
import mil.army.nlac.commons.core.oracle.ConnectionSupplier;
import mil.army.nlac.commons.core.oracle.UCPoolManager;
import mil.army.nlac.commons.core.util.TimestampRandomUUID;
import mil.army.nlac.commons.core.util.cli.JobEnv;
import mil.army.nlac.commons.jobs.model.op.DataSetMetaData.ProcessStatus;

class JUDataSetMetaDataORM {
	private static final String DAT_FILE_NM_SFTPIN = "maars(\\d{6})\\.dat";
	private static final Pattern DAT_FILE_PAT = Pattern.compile(DAT_FILE_NM_SFTPIN);
	private static final DateTimeFormatter DAT_FILE_DTF = DateTimeFormatter.ofPattern("MMddyy");

	private static Logger LOGGER = LoggerFactory.getLogger(JUDataSetMetaDataORM.class);

	private ConnectionSupplier connSupplier;

	private DataSetMetaDataORM dataSetMetaDataORM;

	@BeforeAll
	static void setUpBeforeClass() throws Exception {
	}

	@AfterAll
	static void tearDownAfterClass() throws Exception {
	}

	@BeforeEach
	void setUp() throws Exception {
	}

	@AfterEach
	void tearDown() throws Exception {
	}


//	@Test
	void testRegisterFile() {
		LOGGER.info("\n\n====== TEST: DataSetMetaDataORM RegisterFile ======\n");

		connSupplier = UCPoolManager.getInstance().getPool("ucp://nlac/JOB_LOGGER");
		dataSetMetaDataORM = new DataSetMetaDataORM(connSupplier);
		Path path = Paths.get("C:/!junit/nlac/var/data/provider/MAARS/maars010121.dat");
		URL generalURL = null;
		String digestSSH256 = null;
		try {
			generalURL = path.toUri().toURL();
			digestSSH256 = CoreFileUtils.digestSHA256AsHex(path);
		} catch (MalformedURLException e1) {
			fail(e1);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ImmutableCompositeName compName = new ImmutableCompositeName("provider/MAARS");
		ZonedDateTime generalTS = JobEnv.getNowZonedDateTime();
		UUID generalUUID = new TimestampRandomUUID(generalTS).asUUID();
		
		DataSetMetaData srcfile = new DataSetMetaData()
				.withParentUUID(generalUUID)
				.withArchiveUUID(generalUUID)
				.withDataSetName(path.getFileName())
				.withDigestSHA256(digestSSH256)
				.withExternalURL(generalURL)
				.withInternalURL(generalURL)
				.withAsOf(generalTS)
				.withAsOfPrecision(ChronoUnit.MINUTES)
				.withlastModified(generalTS)
				.withlastModifiedPrecision(ChronoUnit.MINUTES)
				.withProcessStatus(ProcessStatus.NEW)
				.withMediaType(MediaType.APP_JSON)
				.withPUID(PRONOMUniqueId.JSON)
				.withRecvJobRunUUID(generalUUID)
				.withRecvTS(generalTS)
				.withLoadJobRunUUID(generalUUID)
				.withLoadTS(generalTS)
				.withPurgeJobRunUUID(generalUUID)
				.withPurgeTS(generalTS)
				.withInterfaceId(compName);

		try {
			LOGGER.info(String.format("srcfile for File to load: %s", srcfile.toString()));
			dataSetMetaDataORM.registerFile(srcfile);
			LOGGER.info(String.format("srcfile %s loaded successfully! ", srcfile.toString()));
		} catch (SQLException e) {
			fail(e);
		}
	}
	
	//TODO:
	/*
	 * Update:
	 * 		updateLoadStatus(final DataSetMetaData osf)
	 *
	 * Select Missing:
	 * 
	 * 				lookupSourcesNotLoaded(final Map<Path,DataSetMetaData> osfMap)
	 * make new srcfile w/o load LOAD_TASK_RUN_UUID IS NULL (orm LINE 105)
	 */
	
	@Test
	void testLookupNotLoaded() {
		LOGGER.info("\n\n====== TEST: DataSetMetaDataORM lookupSourcesNotLoaded ======\n");

		connSupplier = UCPoolManager.getInstance().getPool("ucp://nlac/JOB_LOGGER");
		dataSetMetaDataORM = new DataSetMetaDataORM(connSupplier);
		Path path = Paths.get("C:/!junit/nlac/var/data/provider/MAARS/maars010121.dat");
		URL generalURL = null;
		String digestSSH256 = null;
		try {
			generalURL = path.toUri().toURL();
			digestSSH256 = CoreFileUtils.digestSHA256AsHex(path);
		} catch (MalformedURLException e1) {
			fail(e1);
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		ImmutableCompositeName compName = new ImmutableCompositeName("provider/MAARS");
		ZonedDateTime generalTS = JobEnv.getNowZonedDateTime();
		UUID generalUUID = new TimestampRandomUUID(generalTS).asUUID();
		
		DataSetMetaData srcfile = new DataSetMetaData()
				.withParentUUID(generalUUID)
				.withArchiveUUID(generalUUID)
				.withDataSetName(path.getFileName())
				.withDigestSHA256(digestSSH256)
				.withExternalURL(generalURL)
				.withInternalURL(generalURL)
				.withAsOf(generalTS)
				.withAsOfPrecision(ChronoUnit.MINUTES)
				.withlastModified(generalTS)
				.withlastModifiedPrecision(ChronoUnit.MINUTES)
				.withProcessStatus(ProcessStatus.NEW)
				.withMediaType(MediaType.APP_JSON)
				.withPUID(PRONOMUniqueId.JSON)
				.withRecvJobRunUUID(generalUUID)
				.withRecvTS(generalTS)
//				.withLoadJobRunUUID(generalUUID)
				.withLoadTS(generalTS)
				.withPurgeJobRunUUID(generalUUID)
				.withPurgeTS(generalTS)
				.withInterfaceId(compName);

		try {
			LOGGER.info(String.format("srcfile for File to load: %s", srcfile.toString()));
			dataSetMetaDataORM.registerFile(srcfile);
			LOGGER.info(String.format("srcfile %s loaded successfully! ", srcfile.toString()));
			// notLoadedMap is Collections.singletonMap
			/// AND in lookupSourcesNotLoaded() osfMap.put() throws UnsupportedOperationException
			Map<Path,DataSetMetaData> notLoadedMap = (Map<Path,DataSetMetaData>)Collections.singletonMap((Path)path.getFileName(), (DataSetMetaData)srcfile);
			// This call throws "Exception: expected 1 found many"
			dataSetMetaDataORM.lookupSourcesNotLoaded(notLoadedMap);
			LOGGER.info(String.format("srcfile %s NOT loaded successfully! ", srcfile.toString()));
		} catch (SQLException e) {
			fail(e);
		}
	}
	
	
}
