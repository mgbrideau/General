package mil.army.nlac.commons.jobs.model.op;

import java.nio.file.Path;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.time.temporal.ChronoUnit;
import java.util.Collection;
import java.util.Collections;
import java.util.LinkedHashMap;
import java.util.Map;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import mil.army.nlac.commons.core.data.PRONOMUniqueId;
import mil.army.nlac.commons.core.http.MediaType;
import mil.army.nlac.commons.core.oracle.ConnectionSupplier;
import mil.army.nlac.commons.core.oracle.jpa.ConnectionWrapper;
import mil.army.nlac.commons.core.oracle.jpa.DigestHexRawBinder;
import mil.army.nlac.commons.core.oracle.jpa.EnumNameBinder;
import mil.army.nlac.commons.core.oracle.jpa.EnumStringBinder;
import mil.army.nlac.commons.core.oracle.jpa.PreparedStatementWrapper;
import mil.army.nlac.commons.core.oracle.jpa.ResultSetWrapper;
import mil.army.nlac.commons.core.oracle.jpa.URLStringBinder;
import mil.army.nlac.commons.core.oracle.jpa.UUIDRawBinder;
import mil.army.nlac.commons.core.oracle.jpa.ZonedDateTimeBinder;
import mil.army.nlac.commons.jobs.model.op.DataSetMetaData.ProcessStatus;

public class DataSetMetaDataORM {
	private static Logger LOGGER = LoggerFactory.getLogger(DataSetMetaDataORM.class);

	private URLStringBinder urlbind = URLStringBinder.getInstance();
	private UUIDRawBinder uuidbind = UUIDRawBinder.getInstance();
	private DigestHexRawBinder shabind = DigestHexRawBinder.getInstance();
	private ZonedDateTimeBinder zdtbind = ZonedDateTimeBinder.getInstance();
	private EnumStringBinder<ProcessStatus> filestatusbind = new EnumStringBinder<ProcessStatus>(new ProcessStatus.ProcessStatusStringMapper()); 
	private EnumStringBinder<MediaType>   mediatypebind = new EnumStringBinder<MediaType>(new MediaType.MediaTypeStringMapper()); 
	private EnumStringBinder<PRONOMUniqueId>   pronombind = new EnumStringBinder<PRONOMUniqueId>(new PRONOMUniqueId.PRONOMUniqueIdStringMapper()); 
	private EnumNameBinder<ChronoUnit>   enumnamebind = new EnumNameBinder<ChronoUnit>(ChronoUnit.class); 
	
	private static final String 
		INS_OP_SRC = 
			"insert into N3_OP.OP_DATASET( "+
			/*01*/ "   UUID, "+
			/*02*/ "   PARENT_UUID, "+
			/*03*/ "   ARCHIVE_UUID, "+
			/*04*/ "   QNAME_NAMESPACE, "+
			/*05*/ "   QNAME_LOCAL_PART, "+
			/*06*/ "   DIGEST_SHA256, "+
			/*07*/ "   URL_EXTERNAL, "+
			/*08*/ "   URL_INTERNAL, "+
			/*09*/ "   ASOF_TS, "+
			/*10*/ "   ASOF_PRECISION, "+
			/*11*/ "   LAST_MODIFIED_TS, "+
			/*12*/ "   LAST_MODIFIED_PRECISION, "+
			/*13*/ "   PROCESS_STATUS, "+
			/*14*/ "   MEDIA_TYPE, "+
			/*15*/ "   PUID, "+
			/*16*/ "   RECV_TASK_RUN_UUID, "+
			/*17*/ "   RECV_TS, "+
			/*18*/ "   LOAD_TASK_RUN_UUID, "+
			/*19*/ "   LOAD_TS, "+
			/*20*/ "   PURGE_TASK_RUN_UUID, "+
			/*21*/ "   PURGE_TS, "+
			/*22*/ "   ROW$INS_TS, "+
			/*23*/ "   ROW$UPD_TS "+
			") values (?,?,?,?,?,?,?,?,?,?, "+
					  "?,?,?,?,?,?,?,?,?,?, "+
					  "?,?,?)",
		UPD_OP_SRC_LOAD = 
			"update N3_OP.OP_DATASET  set "+
			/*1*/ "   PROCESS_STATUS = ?, "+
			/*2*/ "   LOAD_TASK_RUN_UUID = ?, "+
			/*3*/ "   LOAD_TS = ?, "+
			/*4*/ "   ROW$UPD_TS = ? "+
			/*5*/ "where UUID = ?",
			
		SEL_OP_SRC_NOTLOADED = 
			"select "+
			/*01*/ "   UUID, "+
			/*02*/ "   PARENT_UUID, "+
			/*03*/ "   ARCHIVE_UUID, "+
			/*04*/ "   QNAME_NAMESPACE, "+
			/*05*/ "   QNAME_LOCAL_PART, "+
			/*06*/ "   DIGEST_SHA256, "+
			/*07*/ "   URL_EXTERNAL, "+
			/*08*/ "   URL_INTERNAL, "+
			/*09*/ "   ASOF_TS, "+
			/*10*/ "   ASOF_PRECISION, "+
			/*11*/ "   LAST_MODIFIED_TS, "+
			/*12*/ "   LAST_MODIFIED_PRECISION, "+
			/*13*/ "   PROCESS_STATUS, "+
			/*14*/ "   MEDIA_TYPE, "+
			/*15*/ "   PUID, "+
			/*16*/ "   RECV_TASK_RUN_UUID, "+
			/*17*/ "   RECV_TS, "+
			/*18*/ "   LOAD_TASK_RUN_UUID, "+
			/*19*/ "   LOAD_TS, "+
			/*20*/ "   PURGE_TASK_RUN_UUID, "+
			/*21*/ "   PURGE_TS, "+
			/*22*/ "   ROW$INS_TS, "+
			/*23*/ "   ROW$UPD_TS, "+
			/*24*/ "   ROW$ARCV_TS "+
			"from N3_OP.OP_DATASET "+
			"where QNAME_NAMESPACE = ? and QNAME_LOCAL_PART = ? and DIGEST_SHA256 = ? and LOAD_TASK_RUN_UUID is null";
		
	
	private ConnectionSupplier cs;
	public DataSetMetaDataORM(final ConnectionSupplier cs) { this.cs = cs; }


	public void lookupSourcesNotLoaded(final Map<Path,DataSetMetaData> osfMap) throws SQLException {
		try(ConnectionWrapper conn = ConnectionWrapper.newConnection(cs)) {
			try(PreparedStatementWrapper pstmtw = new PreparedStatementWrapper(conn.unwrap().prepareCall(SEL_OP_SRC_NOTLOADED))) {
				DigestHexRawBinder shabind = DigestHexRawBinder.getInstance();
				for(Map.Entry<Path,DataSetMetaData> kv: osfMap.entrySet()) {
					DataSetMetaData v = kv.getValue();
					if(v == null) continue;
					pstmtw.unwrap().clearParameters();
					pstmtw.setString(1, v.getInterfaceId());
					pstmtw.setString(2, v.getDataSetName());
					shabind.set(pstmtw.unwrap(), 3, v.getDigestSHA256());
					DataSetMetaData newOSF = loadObject(pstmtw.unwrap());
//					osfMap.put(Path[provider/MAARS],  DataSetMetaData)
//					java.lang.UnsupportedOperationException
					osfMap.put(kv.getKey(), newOSF);
				}
			}
		} catch(SQLException e) {
			throw e;
		}
	}
	
	/**
	 * Insert all files
	 * @param files
	 * @return map of failed files
	 * @throws SQLException if connection/prepareStatement fails
	 */
	public Map<DataSetMetaData,SQLException> registerAllFiles(Collection<DataSetMetaData> files) throws SQLException {
		Map<DataSetMetaData,SQLException> failed = new LinkedHashMap<DataSetMetaData,SQLException>();
		try(ConnectionWrapper conn = ConnectionWrapper.newConnection(cs)) {
			try(PreparedStatementWrapper pstmtw = new PreparedStatementWrapper(conn.unwrap().prepareStatement(INS_OP_SRC))) {
				for(DataSetMetaData osf: files) {
					try {
						pstmtw.clearParameters();
						pstmtw.set(1, osf.getUuid(), uuidbind);
						pstmtw.set(2, osf.getParentUUID(), uuidbind);
						pstmtw.set(3, osf.getArchiveUUID(), uuidbind);
						pstmtw.setString(4, osf.getInterfaceId());
						pstmtw.setString(5, osf.getDataSetName());
						pstmtw.set(6, osf.getDigestSHA256(), shabind);
						pstmtw.setString(7, osf.getExternalURL());
						pstmtw.setString(8, osf.getInternalURL());
						pstmtw.set(9, osf.getAsOf(), zdtbind);
						pstmtw.setString(10, osf.getAsOfPrecision());
						pstmtw.set(11, osf.getLastModified(), zdtbind);
						pstmtw.setString(12, osf.getLastModifiedPrecision());
						pstmtw.set(13, osf.getProcessStatus(), filestatusbind);
						pstmtw.set(14, osf.getMediaType(), mediatypebind);
						pstmtw.setString(15, osf.getPuid());
						pstmtw.set(16, osf.getRecvTaskRunUUID(), uuidbind);
						pstmtw.set(17, osf.getRecvTS(), zdtbind);
						pstmtw.set(18, osf.getLoadTaskRunUUID(), uuidbind);
						pstmtw.set(19, osf.getLoadTS(), zdtbind);
						pstmtw.set(20, osf.getPurgeTaskRunUUID(), uuidbind);
						pstmtw.set(21, osf.getPurgeTS(), zdtbind);
						pstmtw.set(22, osf.getRowInsTS(), zdtbind);
						pstmtw.set(23, osf.getRowUpdTS(), zdtbind);
						pstmtw.executeUpdate();
						conn.commit();
					} catch(SQLException e) {
						failed.put(osf, e);
					}
				}
			}
		}
		return failed;
	}
	
	/**
	 * Insert a new source file
	 * @param osf
	 * @throws SQLException
	 */
	public void registerFile(final DataSetMetaData osf) throws SQLException {
		Map<DataSetMetaData,SQLException> map = registerAllFiles(Collections.singleton(osf));
		if(!map.isEmpty()) {
			throw map.get(osf);
		} 
	}
	
	/**
	 * Update source file load attributes
	 * @param osf
	 * @throws SQLException
	 */
	public void updateLoadStatus(final DataSetMetaData osf) throws SQLException {
		try(ConnectionWrapper conn = ConnectionWrapper.newConnection(cs)) {
			try(PreparedStatementWrapper pstmtw = new PreparedStatementWrapper(conn.unwrap().prepareCall(UPD_OP_SRC_LOAD))) {
				UUIDRawBinder uuidbind = UUIDRawBinder.getInstance();
				ZonedDateTimeBinder zdtbind = ZonedDateTimeBinder.getInstance();
				pstmtw.set(1, osf.getProcessStatus(), filestatusbind);
				pstmtw.set(2, osf.getLoadTaskRunUUID(), uuidbind);
				pstmtw.set(3, osf.getLoadTS(), zdtbind);
				pstmtw.set(4, osf.getRowUpdTS(), zdtbind);
				pstmtw.set(5, osf.getUuid(), uuidbind);
				pstmtw.executeUpdate();
				conn.commit();
			}
		} catch(SQLException e) {
			throw e;
		}
	}

	/**
	 * Load pojo from db record
	 * @param rs
	 * @return
	 * @throws SQLException
	 */
	protected DataSetMetaData loadObject(final ResultSet rs) throws SQLException {
		return 
			new DataSetMetaData(uuidbind.get(rs, 1))
			.withParentUUID(uuidbind.get(rs, 2))
			.withArchiveUUID(uuidbind.get(rs, 3))
			.withInterfaceId(rs.getString(4))
			.withDataSetName(rs.getString(5))
			.withDigestSHA256(shabind.get(rs, 6))
			.withExternalURL(urlbind.get(rs, 7))
			.withInternalURL(urlbind.get(rs, 8))
			.withAsOf(zdtbind.get(rs, 9))
			.withlastModified(zdtbind.get(rs, 11))
			.withProcessStatus(filestatusbind.get(rs,13))
			.withMediaType(mediatypebind.get(rs, 14))
			.withRecvJobRunUUID(uuidbind.get(rs, 16))
			.withRecvTS(zdtbind.get(rs, 17))
			.withLoadJobRunUUID(uuidbind.get(rs, 18))
			.withLoadTS(zdtbind.get(rs, 19))
			.withPurgeJobRunUUID(uuidbind.get(rs, 20))
			.withPurgeTS(zdtbind.get(rs, 21))
			.withRowInsTS(zdtbind.get(rs, 22))
			.withRowUpdTS(zdtbind.get(rs, 23));
//	The following .with()'s exit without error and terminate app.	
//			.withAsOfPrecision(enumnamebind.get(rs, 10))
//			.withlastModifiedPrecision(enumnamebind.get(rs, 12))
//			.withPUID(pronombind.get(rs, 15)) 
//			.withRowArcvTS(zdtbind.get(rs, 24));
	}

	
	protected DataSetMetaData loadObject(final PreparedStatement stmt) throws SQLException {
		DataSetMetaData osf = null;
		try(ResultSetWrapper rsw = ResultSetWrapper.forQuery(stmt)) {
			while(rsw.next()) {
				if(osf != null) throw new SQLException("expected 1 found many");
				osf = loadObject(rsw.unwrap());
			}
			return osf;
		}
	}
	
}
